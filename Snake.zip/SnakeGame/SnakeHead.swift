//
//  SnakeHead.swift
//  SnakeGame
//
//  Created by Андрей Щекатунов on 28.06.2020.
//  Copyright © 2020 Andrey Shchekatunov. All rights reserved.
//

import SpriteKit

class SnakeHead: SnakeBodyPart {
    override init(position: CGPoint) {
        super.init(position: position)
        physicsBody?.categoryBitMask = CollisionCategories.SnakeHead
        physicsBody?.contactTestBitMask = CollisionCategories.Apple | CollisionCategories.EdgeBody | CollisionCategories.Snake
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
